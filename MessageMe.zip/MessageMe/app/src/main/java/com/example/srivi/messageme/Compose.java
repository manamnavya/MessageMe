package com.example.srivi.messageme;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class Compose extends AppCompatActivity {

    FirebaseAuth firebaseAuth;
    DatabaseReference databaseReference;
    DatabaseReference databaseUsers;
    ArrayList<User> users = new ArrayList<>(  );
    TextView tvTo;
    CharSequence[] userNames;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_compose );
        setTitle( "Compose Message" );
        getSupportActionBar().setDisplayShowHomeEnabled( true );
        getSupportActionBar().setLogo( R.drawable.ic_launcher );
        getSupportActionBar().setDisplayUseLogoEnabled( true );

        tvTo = findViewById( R.id.tvTo );
        final AlertDialog.Builder builder = new AlertDialog.Builder( Compose.this )
                .setTitle( "Users" );
        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference();
        databaseUsers = databaseReference.child( "users" );
        databaseUsers.addValueEventListener( new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot temp:dataSnapshot.getChildren()) {
                    User tempUser = temp.getValue(User.class);
                    users.add( tempUser );
                }
                Log.d("demo", String.valueOf( users.size()));
                userNames = new CharSequence[users.size()];
                for(int i=0;i<users.size();i++)
                    userNames[i] = users.get( i ).firstName+" "+users.get( i ).lastName;
                Log.d("demo", String.valueOf( userNames.length));

                builder.setItems( userNames, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        tvTo.setText( "To : "+userNames[i] );
                    }
                } );

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        } );
        final AlertDialog alertDialog = builder.create();

        findViewById( R.id.ibContact ).setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                alertDialog.show();
            }
        } );
    }
}
